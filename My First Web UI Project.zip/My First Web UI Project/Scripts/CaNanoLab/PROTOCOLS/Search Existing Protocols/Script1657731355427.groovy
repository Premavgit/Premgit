import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.maximizeWindow(FailureHandling.CONTINUE_ON_FAILURE)

WebUI.delay(2)

WebUI.navigateToUrl(GlobalVariable.Url)

WebUI.setText(findTestObject('CaNanoLab/Login/Login_LOGIN ID'), GlobalVariable.Username)

WebUI.setEncryptedText(findTestObject('CaNanoLab/Login/Login_PASSWORD'), GlobalVariable.Password)

WebUI.click(findTestObject('CaNanoLab/Login/Login_button'))

'Search Existing Protocols'
WebUI.comment('Search Existing Protocols')

WebUI.click(findTestObject('CaNanoLab/PROTOCOLs/PROTOCOLS Tab'))

WebUI.click(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/Pro_SearchExisting Protocols'))

WebUI.click(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/Protocol Type dd'))

WebUI.selectOptionByLabel(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/Protocol Type dd'), 'in vitro assay', false)

WebUI.click(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/Protocol Name contain dd'))

WebUI.setText(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/Protocol Name'), 'PVProtocol1')

not_run: WebUI.click(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/Protocol Name'))

WebUI.click(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/button_Search'))

WebUI.click(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/Add to Favorites'))

WebUI.click(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/Edit Protocol'))

WebUI.scrollToElement(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/Edit_button_Update'), 1)

WebUI.click(findTestObject('CaNanoLab/PROTOCOLs/Search Existing/Edit_button_Update'))

WebUI.click(findTestObject(null))

WebUI.click(findTestObject(null))

WebUI.click(findTestObject(null))

WebUI.click(findTestObject(null))

WebUI.click(findTestObject(null))

WebUI.click(findTestObject(null))

WebUI.click(findTestObject(null))

WebUI.click(findTestObject(null))

WebUI.click(findTestObject(null))

