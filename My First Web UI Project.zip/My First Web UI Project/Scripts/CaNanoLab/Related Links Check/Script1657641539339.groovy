import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.maximizeWindow(FailureHandling.CONTINUE_ON_FAILURE)

WebUI.navigateToUrl(GlobalVariable.Url)

not_run: WebUI.setText(findTestObject('CaNanoLab/Login/Login_LOGIN ID'), GlobalVariable.Username)

not_run: WebUI.setText(findTestObject('CaNanoLab/Login/Login_PASSWORD'), GlobalVariable.Password)

not_run: WebUI.click(findTestObject('CaNanoLab/Login/Login_button'))

WebUI.click(findTestObject('CaNanoLab/Related Links/NCI_caNanoLab Wiki'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/NCI_ISA-TAB-Nano Wiki'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/NCI_Nanotechnology Working Group'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/NCI_NCI CBIIT Home'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/NCI_NCI Home'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/NCI_NCI'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/NCI_NCIP HUB'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/NCI_NCL Home'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/External_eNanoMapper'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/External_nanoHUB'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/External_NBI'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/External_NIOSH NIL'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/External_OECD'))

WebUI.delay(2)

WebUI.click(findTestObject('CaNanoLab/Related Links/External_SAFENANO'))

WebUI.delay(2)

WebUI.click(findTestObject(null))

WebUI.click(findTestObject(null))

