<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Create a New Sample</name>
   <tag></tag>
   <elementGuidId>b61895fa-970b-4781-b6d4-7960fa66f55b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//td[@id='maincontent']/div/table[2]/tbody/tr[2]/td/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td.sidebarContent > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>390b199f-ab94-4a13-bf54-8d79506cd9e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/#/submitSample</value>
      <webElementGuid>ce916b4f-a5b9-40d9-945a-3393ec38c255</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Create
                a New Sample </value>
      <webElementGuid>4dda62f7-4c89-45bf-a394-dca4d73e3d56</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;maincontent&quot;)/div[@class=&quot;spacer ng-scope&quot;]/table[@class=&quot;sidebarSection&quot;]/tbody[1]/tr[@class=&quot;ng-scope&quot;]/td[@class=&quot;sidebarContent&quot;]/a[1]</value>
      <webElementGuid>dd388ea6-d7af-49c0-b497-f3588d866a42</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//td[@id='maincontent']/div/table[2]/tbody/tr[2]/td/a</value>
      <webElementGuid>3a3831a1-252b-492d-9385-962f66deed6f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Create
                a New Sample')]</value>
      <webElementGuid>01afa264-453d-4fa7-a424-9ee9a2fc7d09</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SAMPLE LINKS'])[1]/following::a[1]</value>
      <webElementGuid>f99e5889-f972-4826-94e0-76f15779e184</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/#/submitSample')]</value>
      <webElementGuid>c441dd5c-6399-4fbc-ae49-8ffde76bb35a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[2]/td/a</value>
      <webElementGuid>1a2442d5-1eb2-48ce-ae51-d54731186a2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/#/submitSample' and (text() = ' Create
                a New Sample ' or . = ' Create
                a New Sample ')]</value>
      <webElementGuid>d04347b0-9471-47f5-96e8-bc6ce4115740</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
