<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Pro_Createa New Protocol</name>
   <tag></tag>
   <elementGuidId>88f16d83-bc13-414d-b29d-10aa52369d1c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//td[@id='maincontent']/div/div/table/tbody/tr[2]/td/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td.sidebarContent > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>162a4ed1-9a09-4fe5-9333-702f22c2a7a8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#/submitProtocol</value>
      <webElementGuid>0f758679-c04f-4fa0-9e50-1d04205957f1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Create
						a New Protocol </value>
      <webElementGuid>97cd1f0b-6826-4bb9-ab3d-cb4e196355e3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;maincontent&quot;)/div[@class=&quot;spacer ng-scope&quot;]/div[1]/table[@class=&quot;sidebarSection&quot;]/tbody[1]/tr[@class=&quot;ng-scope&quot;]/td[@class=&quot;sidebarContent&quot;]/a[1]</value>
      <webElementGuid>1877e2fb-d7fa-489e-a978-392fab67c552</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//td[@id='maincontent']/div/div/table/tbody/tr[2]/td/a</value>
      <webElementGuid>bb812a38-b09b-4356-aa8a-f7d4cf4aa2e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Create
						a New Protocol')]</value>
      <webElementGuid>d2eee8d2-d75a-4f6e-b2c2-fa43a7546cb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PROTOCOL LINKS'])[1]/following::a[1]</value>
      <webElementGuid>a3acd7ff-585a-4c90-841f-5615b221fc5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#/submitProtocol')]</value>
      <webElementGuid>4cb88a0d-c7ea-43d9-a9bf-c7fe66e91c7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[2]/td/a</value>
      <webElementGuid>28f110c6-3f93-4614-b36d-e88093883c89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#/submitProtocol' and (text() = ' Create
						a New Protocol ' or . = ' Create
						a New Protocol ')]</value>
      <webElementGuid>9f45f0f4-636d-4f98-b547-e4af4e7be3c5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
