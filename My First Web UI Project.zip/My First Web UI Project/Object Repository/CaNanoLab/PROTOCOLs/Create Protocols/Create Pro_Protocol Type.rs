<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Create Pro_Protocol Type</name>
   <tag></tag>
   <elementGuidId>32bbe7f7-d948-4a0c-b668-9b6747b083e2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='type']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#type</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>0fab33e2-d362-40a0-ae8b-7e71fb7ad1f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-disabled</name>
      <type>Main</type>
      <value>loader</value>
      <webElementGuid>75f1e8e5-41dc-4c8f-96da-5a1ec0c6c8ed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>type</value>
      <webElementGuid>28a75ff1-80a9-4e9b-81df-51df400f9e42</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-model</name>
      <type>Main</type>
      <value>protocolForm.type</value>
      <webElementGuid>5a4a6318-38c0-4911-b800-99c04f004d9f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-pristine ng-untouched ng-valid ng-empty</value>
      <webElementGuid>7e58ca9d-0d2d-4aa1-8225-9ac70a22fa6b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    Endotoxin
                
                    in vitro assay
                
                    in vivo assay
                
                    physico-chemical assay
                
                    purification
                
                    radio labeling
                
                    safety
                
                    sample preparation
                
                    sterility
                
                    synthesis
                
                
                    [other]
                            
            </value>
      <webElementGuid>6916ba11-8b0b-4515-b748-8f0722bbbdbb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;type&quot;)</value>
      <webElementGuid>9773f744-1b07-4e03-a232-17c716ff922b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='type']</value>
      <webElementGuid>efa99b4c-f60b-4c14-bf9e-40e5ec7b562a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='categoryPrompt']/select</value>
      <webElementGuid>ce08fae8-3d72-4c24-9362-b0ca3bb4622a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Protocol Type*'])[1]/following::select[1]</value>
      <webElementGuid>502b8f10-8500-4276-bc70-dd7d72ad6b8e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Glossary'])[1]/following::select[1]</value>
      <webElementGuid>9ca2712c-4d4c-416a-aa6f-e788cbafe901</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Protocol Name*'])[1]/preceding::select[1]</value>
      <webElementGuid>d1bd1239-0dd2-4846-ba07-e199e45d3179</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Protocol Abbreviation'])[1]/preceding::select[1]</value>
      <webElementGuid>cb3aebd9-edc4-465a-8941-998d0e707c35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>928199c3-0275-4934-adc7-301814286a45</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'type' and (text() = '
                
                    Endotoxin
                
                    in vitro assay
                
                    in vivo assay
                
                    physico-chemical assay
                
                    purification
                
                    radio labeling
                
                    safety
                
                    sample preparation
                
                    sterility
                
                    synthesis
                
                
                    [other]
                            
            ' or . = '
                
                    Endotoxin
                
                    in vitro assay
                
                    in vivo assay
                
                    physico-chemical assay
                
                    purification
                
                    radio labeling
                
                    safety
                
                    sample preparation
                
                    sterility
                
                    synthesis
                
                
                    [other]
                            
            ')]</value>
      <webElementGuid>c096b670-2753-4d34-a268-2497ad2f6350</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
