<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Pro_SearchExisting Protocols</name>
   <tag></tag>
   <elementGuidId>05795be0-9714-4297-9a67-37640119996d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//td[@id='maincontent']/div/div/table/tbody/tr[4]/td/a</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>98143477-5bcf-4938-b411-186ded4ceea7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#/searchProtocol</value>
      <webElementGuid>78a3f93d-b969-433b-b5bd-1347b070c310</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Search
				Existing Protocols </value>
      <webElementGuid>f8cd03e5-b09f-4fb8-8c25-5a8ab146696a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;maincontent&quot;)/div[@class=&quot;spacer ng-scope&quot;]/div[1]/table[@class=&quot;sidebarSection&quot;]/tbody[1]/tr[4]/td[@class=&quot;sidebarContent&quot;]/a[1]</value>
      <webElementGuid>9e7601f8-2a94-4d5a-86e0-b60a048617a9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//td[@id='maincontent']/div/div/table/tbody/tr[4]/td/a</value>
      <webElementGuid>cc5eca32-60c2-43e8-b262-3a9289f5a2f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Search
				Existing Protocols')]</value>
      <webElementGuid>3383bd5a-afee-49a4-bc37-f3b6aef15ce7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CONTACT US'])[1]/preceding::a[1]</value>
      <webElementGuid>7c11291e-2230-48d3-92ab-fb42ef30b1f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#/searchProtocol')]</value>
      <webElementGuid>89164600-a914-43e0-8b7d-df6b4273d1f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[4]/td/a</value>
      <webElementGuid>75166968-adfb-487e-b3f5-91000b1a165e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#/searchProtocol' and (text() = 'Search
				Existing Protocols ' or . = 'Search
				Existing Protocols ')]</value>
      <webElementGuid>8c6d4d1c-0d1b-4cd8-9676-efd51ae01c1e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
