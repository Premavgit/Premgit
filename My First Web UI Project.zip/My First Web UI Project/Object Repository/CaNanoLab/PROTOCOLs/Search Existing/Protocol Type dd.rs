<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Protocol Type dd</name>
   <tag></tag>
   <elementGuidId>64ed81d1-e40b-43b8-98fc-a8c744dcee60</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='type']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#type</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>6479c4fa-a6ed-4500-8a75-2fe373ec3067</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-disabled</name>
      <type>Main</type>
      <value>loader</value>
      <webElementGuid>29748aca-1c07-4025-8c39-fbee2ad263f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>type</value>
      <webElementGuid>a879786c-502b-467c-867e-3feb0b996189</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-model</name>
      <type>Main</type>
      <value>searchProtocolForm.protocolType</value>
      <webElementGuid>bf3cffb2-981f-467c-9bc4-f7f0ee2fe205</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-pristine ng-untouched ng-valid ng-empty</value>
      <webElementGuid>43c2f037-674a-47af-b716-5b2dea178373</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            in vitro assay
                        
                            in vivo assay
                        
                            physico-chemical assay
                        
                            radio labeling
                        
                            safety
                        
                            sample preparation
                        
                            sterility
                        
                            synthesis
                        
                    </value>
      <webElementGuid>61fba68d-c458-4bea-a994-64437c01e284</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;type&quot;)</value>
      <webElementGuid>b35c728f-43e6-4285-9ced-c58ffd410d92</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='type']</value>
      <webElementGuid>d501ee92-a7f0-41d0-981b-fbe9b8938577</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//td[@id='maincontent']/div/div/table[2]/tbody/tr/td[2]/table/tbody/tr/td/select</value>
      <webElementGuid>b2ef164f-98de-41b6-a55e-253d47f21b28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Protocol Type'])[1]/following::select[1]</value>
      <webElementGuid>51013517-28fe-4906-bc6c-297e9b96f4da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Glossary'])[1]/following::select[1]</value>
      <webElementGuid>2b8f7050-4ea3-4351-98f1-39c0317ba8a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Protocol Name'])[1]/preceding::select[1]</value>
      <webElementGuid>495cc978-52b2-4791-abc3-10e939391bb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Protocol Abbreviation'])[1]/preceding::select[2]</value>
      <webElementGuid>f397e527-5c57-4147-a688-8e5ef4864e5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>107997bf-5ef9-4b82-a77d-0135e6e44306</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'type' and (text() = '
                        
                            in vitro assay
                        
                            in vivo assay
                        
                            physico-chemical assay
                        
                            radio labeling
                        
                            safety
                        
                            sample preparation
                        
                            sterility
                        
                            synthesis
                        
                    ' or . = '
                        
                            in vitro assay
                        
                            in vivo assay
                        
                            physico-chemical assay
                        
                            radio labeling
                        
                            safety
                        
                            sample preparation
                        
                            sterility
                        
                            synthesis
                        
                    ')]</value>
      <webElementGuid>fb776c3b-c43a-485b-bca8-0dd10c3f6d25</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
